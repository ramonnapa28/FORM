function printForm() { // Hide the print button
  const printButton = document.getElementById("printButton");
  printButton.style.display = "none";

  // Perform the print action with a delay
  setTimeout(function() {
    window.print();
  }, 100);

  // Show the print button again after the print dialog is closed
  window.onafterprint = function() {
    const printButton = document.getElementById("printButton");
    printButton.style.display = "inline-block";
  };
}

function calculateTotal() {
    const prevBalance = parseFloat(document.getElementsByName("prevBalance")[0].value);
    const paymentMadeValue = document.getElementsByName("paymentMade")[0].value;
    let paymentMade = 0;

    // Check if paymentMade has a valid value
    if (paymentMadeValue !== "") {
        paymentMade = parseFloat(paymentMadeValue);
    }

    const total = prevBalance - paymentMade;

    document.getElementsByName("shortOver")[0].value = total.toFixed(2);
}

// Add event listeners to the input fields
document.getElementsByName("prevBalance")[0].addEventListener("input", calculateTotal);
document.getElementsByName("paymentMade")[0].addEventListener("input", calculateTotal);


